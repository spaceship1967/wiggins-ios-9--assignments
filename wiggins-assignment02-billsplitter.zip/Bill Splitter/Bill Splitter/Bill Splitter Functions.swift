//
//  billSplitterFunctions.swift
//  Bill Splitter
//
//  Created by Michael Wiggins on 7/6/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation

class Math2 {
    
    func addTwoNumbers(leftOperand:Int, rightOperand:Int)->Int {
        return leftOperand + rightOperand
    }
    
    func subtractTwoNumbers(leftOperand:Int, rightOperand:Int)->Int {
        return leftOperand - rightOperand
    }
    
    func divideTwoNumbers(leftOperand: Int, rightOperand: Int) -> Int! {
        if rightOperand == 0 {
            return nil
        }
        return leftOperand / rightOperand
    }
    
    func multiplyTwoNumbers(leftOperand:Int, rightOperand:Int)->Int {
        return leftOperand*rightOperand
    }

}

