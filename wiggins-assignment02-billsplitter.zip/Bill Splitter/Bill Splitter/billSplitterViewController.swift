//
//  BillSplitterController.swift
//  Bill Splitter
//
//  Created by Michael Wiggins on 7/7/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit

class billSplitterViewController: UIViewController {
    
 
//Declarations
    
    @IBOutlet weak var AmountOfBill: UITextField!
    
    @IBOutlet weak var NumberOfDiners: UITextField!
  
    @IBOutlet weak var TipPercentage: UITextField!
    
    @IBOutlet weak var YourShare: UITextField!
    
//LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
  
    
//convert text to float
    func floatValueFrom(textField: UITextField) -> Float! {
        if
            let text = textField.text {
            return Float(text)
        }
        return nil
    }
    
//Convert text to Int
    func intValueFrom(textField: UITextField) -> Int! {
        if
            let text = textField.text {
            return Int(text)
        }
        return nil
    }
    
//Convert text to Double
    func doubleValueFrom(textField: UITextField) -> Double! {
        if
            let text = textField.text {
            return Double(text)
        }
        return nil
    }
    
//Calculate Split
    
    @IBAction func calculateSplit(sender: AnyObject!) {
        if
            let AmountOfBill = floatValueFrom(AmountOfBill),
            let TipPercentage = floatValueFrom(TipPercentage),
            let NumberOfDiners = floatValueFrom(NumberOfDiners) {
            
            let result = (TipPercentage/100 * AmountOfBill) + (AmountOfBill) / NumberOfDiners
            YourShare.text = "$\(result)"
        }
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    // Dispose of any resources that can be recreated.
}