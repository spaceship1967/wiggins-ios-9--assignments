//
//  generateRandomNumViewController.swift
//  Bill Splitter
//
//  Created by Michael Wiggins on 7/8/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit

class generateRandomNumViewController: UIViewController {
    
@IBOutlet weak var guessNumber: UITextField!

@IBOutlet weak var areYouPsychic: UITextField!


override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
}

override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
}

//Convert text to Int
private func intValueFrom(textField: UITextField) -> Int! {
    if
        let text = textField.text {
        return Int(text)
    }
    return nil
}

//Convert text to Int
private func int32ValueFrom(textField: UITextField) -> UInt32! {
    if
        let text = textField.text {
        return UInt32(text)
    }
    return nil
}

@IBAction func generateRandomNumber(sender: AnyObject) {
    let randomNumberGen = arc4random()
    let guess = int32ValueFrom(guessNumber)
    print(randomNumberGen)
    
    if randomNumberGen == guess {
        areYouPsychic.text = "Yes, you are obviously an alien."
    } else {
        areYouPsychic.text = "Nope, sorry."
        }
    }


}