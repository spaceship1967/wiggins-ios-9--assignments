//
//  randomNumberViewController.swift
//  Bill Splitter
//
//  Created by Michael Wiggins on 7/8/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import UIKit

class randomNumberViewController: UIViewController {
    
//randomNumber Declarations
    @IBOutlet weak var areYouPsychic: UITextField!

    @IBOutlet weak var guessNumber: UITextField!
    
    
//LifeCycle
override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
}
    
//Convert text to Int
    private func intValueFrom(textField: UITextField) -> Int! {
        if
            let text = textField.text {
            return Int(text)
        }
        return nil
    }
   
    //Convert text to Int
    private func int32ValueFrom(textField: UITextField) -> UInt32! {
        if
            let text = textField.text {
            return UInt32(text)
        }
        return nil
    }

//Actions

    @IBAction func generateRandomNumber(sender: AnyObject!) {
        
            let randomNumberGen = arc4random()
            let guess = int32ValueFrom(guessNumber)
        
            if randomNumberGen == guess {
    
            areYouPsychic.text = "Yes, you are obviously an alien." }
        
            else {
        
            areYouPsychic.text = "Nope, sorry."
        
    }
        
        
func overridedidReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
        }
// Dispose of any resources that can be recreated.
        
    }
}