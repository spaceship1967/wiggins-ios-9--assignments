//
//  TaskItemProtocol.swift
//  ToDoList1
//
//  Created by Michael Wiggins on 7/15/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit

/* Make a file and create a protocol called ToDoType or something like that.
 Matt wrote this description:
 
 protocol TaskType {
 //    var title: String { get }
 //    var description: String { get }
 //    var subtasks: [String] { get }
 //}*/
 
 class TaskItemArray {
 
 let title: String
 let description: String
 let subtasks: [String]
 
 init(title: String, description: String, subtasks: [String]) {
 self.title = title
 self.description = description
 self.subtasks = subtasks
 }
 }