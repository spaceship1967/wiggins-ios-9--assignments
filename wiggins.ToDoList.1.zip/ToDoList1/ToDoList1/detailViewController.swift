//
//  detailViewController.swift
//  ToDoList1
//
//  Created by Michael Wiggins on 7/15/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//
//Make a file called DetailViewController and declare some variables. This is the one that has the outlets (labels). You can write them in, but you have to connect these outlets to the mainstoryboard for them to work.

import Foundation
import UIKit

class detailViewController: UIViewController {


// MARK: Declaration
//this variable item, the array, has to be declared as an optional because...well I think it's because if it's not then you run the chance of getting a nil value, a condition which you avoid by using the "as" syntax pattern when you set up your datasource and datamodel. These labels could be text fields, I think, if I wanted to set this for the user to enter the data. Then the "if let" statement would be revised to say the outputs should be equal to the user's entries.
    
    var taskItem:TaskItemArray?
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    // MARK: Lifecycle - this refers to the sequence of events after the view appears
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
       // If the taskItem entered is the same as itself, and of course it will be, then this instructs the compiler to output(print) the task in the label and it also tells it to make the description label equal to the description
        
        if let taskItem = taskItem {
            titleLabel.text = taskItem.title
            descriptionLabel.text = taskItem.description
        }
    }
}
