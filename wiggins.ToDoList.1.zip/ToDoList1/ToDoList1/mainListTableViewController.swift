//
//  File.swift
//  ToDoList1
//
//  Created by Michael Wiggins on 7/15/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit

class MainListTableViewController: UITableViewController {
    
//you have to declare this variable first to create an empty array
    
var taskItems = [TaskItemArray]()

// MARK: Lifecycle

override func viewDidLoad() {
    super.viewDidLoad()
    
// Make a dataModel (I think that's what it's called) here. This is hardcoded but it would probably be a user entering this in a real app. This one takes strings. It could be Ints too, but you'd have to change the syntax a bit, no quotes and you'd have to declare it as such and initialize it on another file or somewhere here. syntax: variableData.append(ArrayName(name:"", name:"", name:"")
    
    
    let tasks = [
            
        TaskItemArray(title: "Clean your apt", description: "put all the books on the shelf", subtasks: ["sock drawer", "bathroom"]),
        
        TaskItemArray(title: "Babysitting on Wednesday", description: "CMA?", subtasks: ["Dad says no iPad for the kid."]),
        
        TaskItemArray(title: "Gym", description: "Cardio 30 min.", subtasks: ["No sugar!"])
    
    ]
    
    taskItems.appendContentsOf(tasks)
}

// MARK: Segue - this is a transition, similar to when you use the interface builder to do "show" a new view, but it's a func that you can get because it's part of the UIKit and the class, so it inherits everything from its class, so it works here.

override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    if let detailViewController = segue.destinationViewController as? detailViewController {
        
        if let indexPath = tableView.indexPathForSelectedRow {
            let TaskItemArray = taskItems[indexPath.row]
            detailViewController.taskItem = TaskItemArray
        }
    }
}

// MARK: UITableViewDataSource

    //This says the number of rows equals the count of the array
override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return taskItems.count
}

//This func is like the coordinates for the location of the cell
override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    
    let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
    
    let TaskItemArray = taskItems[indexPath.row]
    cell.textLabel?.text = TaskItemArray.title
    cell.detailTextLabel?.text = TaskItemArray.description
    
    return cell
}
}