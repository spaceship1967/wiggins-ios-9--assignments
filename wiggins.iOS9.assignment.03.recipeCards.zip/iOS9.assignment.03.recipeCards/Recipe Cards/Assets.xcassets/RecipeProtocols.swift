//
//  RecipeProtocols.swift
//  Recipe Cards
//
//  Created by Michael Wiggins on 7/17/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit

class RecipeItemArray {
    
    let name: String
    let cookingTime: String
    let description: String
    let ingredients: String
    
    init(name: String, cookingTime: String, description: String, ingredients: String) {
        self.name = name
        self.cookingTime = cookingTime
        self.description = description
        self.ingredients = ingredients
    }
}