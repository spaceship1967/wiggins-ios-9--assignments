//
//  MainTableViewController.swift
//  Recipe Cards
//
//  Created by Michael Wiggins on 7/17/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit

class MainTableViewController: UITableViewController {
    
    //Mark: Declarations
    var recipeItems = [RecipeItemArray]()
    

    // Mark: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let recipes = [
            
            RecipeItemArray(name: "Coconut Pistachio Rice Pudding", cookingTime: "Cooking Time: 15 min.", description:"Directions: In a large nonstick sauté pan over medium heat, combine cooked rice and coconut milk. Heat until mixture begins to boil. Decrease heat to low and cook to a simmer, stirring frequently, until mixture begins to thicken, approximately 5 minutes.Increase heat to medium, add coconut cream, coconut milk, sugar, and cardamom. Continue to cook until mixture just begins to thicken again, approximately 5-10 minutes. Use a whisk to prevent the cardamom from clumping.Once mixture begins to thicken, remove from heat and stir in raisins and pistachios.Transfer the mixture to individual serving dishes or a glass bowl and place plastic wrap directly on the surface of the pudding. Serve chilled or at room temperature.", ingredients: "Ingredients: rice, coconut milk, coconut cream sugar, pistachios, cardamom."),
            
            RecipeItemArray(name: "Curry Potato Chips", cookingTime: "Cooking Time: 15 min.", description: "Directions: Slice the potatoes thinly. Using a non-stick pan, take a small amount of ghee or vegetable oil and fry these potatoes chips over a high heat to start with and then turn the heat down and cover. When the potatoes are a little more than half done, add the turmeric, chili powder and some salt. Keep the potatoes moving until they are crispy. When the potatoes are nearly ready (and you will have to be vigilant to ensure they don't get too soft), take the lid off, turn the heat up and stir-fry to enable any excess liquid to evaporate. Garnish with fresh cilantro and serve.", ingredients: "Ingredients: potatoes, tumeric, chili powder, salt, cilantro, ghee or vegetable oil."),
            
            RecipeItemArray(name: "Quick Grits", cookingTime: "Cooking Time: 15 min.", description: "Directions: Bring the water and salt to a boil in a saucepan. Whisk in the grits for 1 minute. When the mixture comes to a boil again, turn the heat down to low. Stir frequently, cook for 10 to 15 minutes. Remove the grits from the heat. Add pepper, salt, ghee and whatever else you like. Stir and eat.", ingredients: "Ingredients: 1 cup of Grits, ghee, salt, pepper. ")
        ]
        
        recipeItems.appendContentsOf(recipes)
    }
    
    // MARK: Segue from mainTableView to detail view
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if let DetailViewController = segue.destinationViewController as? DetailViewController {
            
            if let indexPath = tableView.indexPathForSelectedRow {
                let RecipeItemArray = recipeItems[indexPath.row]
                DetailViewController.recipeItem = RecipeItemArray
            }
        }
    }
    // MARK: UITableViewDataSource
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recipeItems.count
    }
    
    //This func moves you to the detail view.
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
        
        let RecipeItemArray = recipeItems[indexPath.row]
        
        cell.textLabel?.text = RecipeItemArray.name
        cell.detailTextLabel?.text = "Get the Recipe."
        
        return cell
        }
    }