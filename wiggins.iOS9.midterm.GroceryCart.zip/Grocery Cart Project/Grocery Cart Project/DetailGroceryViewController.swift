//
//  DetailViewController.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 7/28/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit

//Mark: Protocol Conformation
protocol DetailGroceryViewControllerDelegate:class {
    func userDidAddNewItem(item: GroceryItem)
}

    
class DetailGroceryViewController: UIViewController {

// MARK: Declaration of variables
    var groceryItem:GroceryItem?
    
    weak var delegate:DetailGroceryViewControllerDelegate?
    

//Mark: Actions
    
    @IBAction func AppleBasket(sender: AnyObject) {
        
        let groceryItem = GroceryItem(name: "Apple Basket", price: "10")
        delegate?.userDidAddNewItem(groceryItem)
        dismissViewControllerAnimated(true, completion: nil)

    }
    

    @IBAction func BananaBasket(sender: AnyObject) {

        let groceryItem = GroceryItem(name: "Banana Basket", price: "10")
        delegate?.userDidAddNewItem(groceryItem)
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    @IBAction func AvocadoBasket(sender: AnyObject) {
        
        let groceryItem = GroceryItem(name: "Avocado Basket", price: "10")
        delegate?.userDidAddNewItem(groceryItem)
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    @IBAction func OrangeBasket(sender: AnyObject) {
        
        let groceryItem = GroceryItem(name: "Orange Basket", price: "10")
        delegate?.userDidAddNewItem(groceryItem)
        dismissViewControllerAnimated(true, completion: nil)
    }
    

    
//Mark: Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
