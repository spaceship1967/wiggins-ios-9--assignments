//
//  DetailViewController.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 7/28/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit

protocol DetailGroceryViewControllerDelegate: class {
    func userDidAddNewItem(item: GroceryItemArray)
}

// Convert text to int
private func intValueFrom(textField: UITextField) -> Int? {
    if let text = textField.text {
        return Int(text)
    }
    return nil
}
class DetailGroceryViewController: UIViewController {

// MARK: Declaration of variables
    var groceryItem:GroceryItemArray?
    weak var delegate: DetailGroceryViewControllerDelegate?
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    
    @IBAction func AppleBasket(sender: AnyObject) {
        
    }

    @IBAction func BananaBasket(sender: AnyObject) {
    }
    
    @IBAction func AvocadoBasket(sender: AnyObject) {
    }
    
    @IBOutlet weak var OrangeBasket: UIButton!
    
    
    // MARK: Lifecycle - this refers to the sequence of events after the view appears
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
//
        
       
        }
    }

