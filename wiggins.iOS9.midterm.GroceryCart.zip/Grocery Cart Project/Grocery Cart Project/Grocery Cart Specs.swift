//
//  Grocery Cart Specs.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 7/28/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation

/* 
 
Build a Grocery Cart app.
 
 The main view controller should be a UITableViewController subclass. It should have a list of items to choose from. It should display, at the very least, the name of the product inside the UITableViewCells. If you want to show additional information, that is up to you. "Design" the app to fit your needs.
 
 Your app should also have a detail view controller that can display more information about each recipe. The user will get to the detail view controller by tapping on any one of the UITableViewCells inside the main UITableViewController described above. You can choose how to display the detailed information about each recipe. Again, "design" the app to fit your needs.
 
 Your app should also have a food object that has the following properties: name, price, picture.
 
 Your app should pass data between the main table view controller and the detail view controller by using the "prepareForSegue" function.
 
 Steps to Delegation:
 
 - Define a protocol
 - Add a property to a class that is the type defined by your protocol
 - In another class, conform to the protocol
 - Connect the two class by setting one class as the delegate
 
 Bonus: Use Protocol Oriented Programming and make the recipe object conform to a recipe protocol. Bonus: Insert images of the recipe that the user is viewing.
 
 */