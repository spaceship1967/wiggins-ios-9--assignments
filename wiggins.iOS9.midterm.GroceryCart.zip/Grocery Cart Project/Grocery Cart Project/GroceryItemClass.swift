//
//  GroceryItemProtocol.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 8/1/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit

class GroceryItem {
let name: String
let price: String

    init(name: String, price: String) {
        self.name = name
        self.price = price
    }
}