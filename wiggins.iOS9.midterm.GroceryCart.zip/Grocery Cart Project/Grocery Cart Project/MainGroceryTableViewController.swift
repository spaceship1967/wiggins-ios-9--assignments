//
//  ViewController.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 7/28/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//


import UIKit

class MainGroceryTableViewController: UITableViewController {
    
//Mark: Declaration of an empty array.
    
    private var groceryItems = [GroceryItemArray]()
    
  
// MARK: UITableViewDataSource
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return groceryItems.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
        
        let groceryItem = groceryItems[indexPath.row]
        cell.textLabel?.text = groceryItem.name
        cell.detailTextLabel?.text = groceryItem.price
        
        return cell
    }
}