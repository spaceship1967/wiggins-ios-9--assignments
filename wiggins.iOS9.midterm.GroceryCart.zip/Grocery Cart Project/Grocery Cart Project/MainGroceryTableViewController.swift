//
//  ViewController.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 7/28/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//


import UIKit

class MainGroceryTableViewController: UITableViewController {
    
//Mark: Declaration of an empty array.
    private var groceryItems = [GroceryItem]()


//Mark: Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    // Convert text to int
    private func intValueFrom(textField: UITextField) -> Int? {
        if let text = textField.text {
            return Int(text)
        }
        return nil
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
//Mark Segue
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "detailsequeidentifier" {
            if let detailViewController = segue.destinationViewController as? DetailGroceryViewController {
                detailViewController.delegate = self
            }
        }
        
        if segue.identifier == "checkOutViewSegue" {
            if let CheckOutViewController = segue.destinationViewController as? CheckOutViewController {
                CheckOutViewController.delegate = self
            }
            
        }
    }

    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return groceryItems.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
        let purchases = groceryItems[indexPath.row]
        
        
        cell.textLabel?.text = purchases.name
        cell.detailTextLabel?.text = purchases.price
        
        return cell
        
    }
    
}

extension MainGroceryTableViewController: DetailGroceryViewControllerDelegate {
    func userDidAddNewItem(purchases: GroceryItem) {
        print("Hello")
        groceryItems.append(purchases)
        tableView.reloadData()
    }
        
}

extension MainGroceryTableViewController: CheckOutViewControllerDelegate {
    
    func calculateBill() -> Double {
            
        var totalAmount:Double = 0
    
        for item in groceryItems {
            if let priceAsDouble = Double(item.price){
                totalAmount += priceAsDouble
            }
        }
    
    return totalAmount
        
    }
    
    func calculateItemsOnOrder()-> Double {
        
        var numberOfItems:Double = 0
       
        for item in groceryItems {
            
            if let numberAsDouble = Double(item.name) {
                numberOfItems += numberAsDouble
            }
        }
        return numberOfItems
        
    }
}
