//
//  checkOutViewController.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 8/1/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit


protocol CheckOutViewControllerDelegate: class{
    
    func calculateBill()-> Double
    func calculateItemsOnOrder()-> Double
}

class CheckOutViewController: UIViewController, UITextFieldDelegate {
    
//Mark: Declaration of Variables
    var totalAmount:Double = 0
    var numberOfItems:Double = 0
    
    weak var delegate: CheckOutViewControllerDelegate?
    
    
    @IBOutlet weak var numberItems: UILabel!
    @IBOutlet weak var Amount: UILabel!
    @IBOutlet weak var Cash: UITextField!
    
    
//Mark: Actions
    @IBAction func
    payButton(sender: AnyObject) {
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(delegate?.calculateBill())
        numberItems.text = "\(numberOfItems)"
        
        print(delegate?.calculateItemsOnOrder())
        Amount.text = "\(totalAmount)"
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "YourChangeSegue" {
            if let yourChangeViewController = segue.destinationViewController as? yourChangeViewController {
                
                yourChangeViewController.textFieldViaSegue = numberItems.text!
                yourChangeViewController.totalAmountViaSegue = Amount.text!
            }
        }
    }
}