//
//  checkOutViewController.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 8/1/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit


protocol CheckOutViewControllerDelegate: class{
    func calculateBill()-> Double
}

class CheckOutViewController: UIViewController, UITextFieldDelegate {
    
//Mark: Declaration of Variables
    var totalAmount:Double = 0
    var numberOfItems:Double = 0
    var checkoutItems = [GroceryItem]()

    weak var delegate: CheckOutViewControllerDelegate?
    
//Mark: Labels and TextFields
    @IBOutlet weak var numberItems: UILabel!
    @IBOutlet weak var Amount: UILabel!
    @IBOutlet weak var Cash: UITextField!
    @IBOutlet weak var YourChange: UILabel!
    
//Mark: Actions
    @IBAction func calculateChange(sender: UIButton){
            
    }
    
//Mark: Life Cycle
    
  override func viewDidLoad() {
        
    }

    override func viewDidAppear(animated: Bool) {
        
         numberItems.text = "\(checkoutItems.count)"
        
        var totalAmount:Double = 0
        
        for item in checkoutItems {
            if let priceAsDouble = Double(item.price){
                print(priceAsDouble)
                totalAmount += priceAsDouble
                Amount.text = "\(totalAmount)"

            }
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}