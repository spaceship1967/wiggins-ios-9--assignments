//
//  checkOutViewController.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 8/1/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit

class checkOutViewController: UIViewController {
    
    @IBAction func Pay(sender: AnyObject) {
    }
}
