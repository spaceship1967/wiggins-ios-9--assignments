//
//  checkOutViewController.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 8/1/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit


protocol CheckOutViewControllerDelegate: class{
    func calculateBill()-> Double
}

class CheckOutViewController: UIViewController {
    
    //Mark: Declaration of Variables
    var totalAmount:Double = 0
    var checkOutItems = [FruitBasket]()
    var cashTendered:Double = 0
    
    weak var delegate: CheckOutViewControllerDelegate?
    
//Mark: Labels and TextFields
    @IBOutlet weak var numberItems: UILabel!
    @IBOutlet weak var Amount: UILabel!
    @IBOutlet weak var Cash: UITextField!
    @IBOutlet weak var yourChange: UILabel!
   
//Mark: Life Cycle
    
  override func viewDidLoad() {
    
 
    }

    override func viewDidAppear(animated: Bool) {
       
        numberItems.text = "\(checkOutItems.count)"
        
        var totalAmount:Double = 0
        
        for item in checkOutItems {
            if let priceAsDouble = Double(item.price){
                print(priceAsDouble)
                totalAmount += priceAsDouble
                Amount.text = "\(totalAmount)"

            }
        }
    }
    
    //Mark: Actions

    @IBAction func Pay(sender: AnyObject) {
        
        if
            let totalAmount = Double(Amount.text!),
            let cashTendered = Double(Cash.text!) {
            let change:Double = cashTendered - totalAmount
            print(change)
            yourChange.text = "\(change)"
            
        }
    
    }
}