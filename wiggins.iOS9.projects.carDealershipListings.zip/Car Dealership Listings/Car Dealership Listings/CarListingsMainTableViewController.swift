//
//  CarListingsMainViewController.swift
//  Car Dealership Listings
//
//  Created by Michael Wiggins on 7/16/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
// Main Story Board shoud be UITableView

import UIKit
import Foundation

class CarListingsMainTableViewController: UITableViewController {
    
    //you have to declare this variable first to create an empty array
    
    var vehicleItems = [VehicleItemArray]()
    
    // Convert text to int
    private func intValueFrom(textField: UILabel) -> Int? {
        if let text = textField.text {
            return Int(text)
        }
        return nil
    }
    // MARK: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        let vehicles = [
        
            VehicleItemArray(make: "Volkswagen", model: "Beetle", year: "1973", price: "$3500.00"),
            
            VehicleItemArray(make: "Ford", model: "Saturn", year: "1990", price: "$3500.00"),
            
            VehicleItemArray(make:"Dodge", model: "Dart", year: "1968", price: "$2500.00")
            
        ]
        
        vehicleItems.appendContentsOf(vehicles)
    }
    // MARK: Segue - this is a transition, similar to when you use the interface builder to do "show" a new view, but it's a func that you can get because it's part of the UIKit and the class, so it inherits everything from its class, so it works here.
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if let DetailViewController = segue.destinationViewController as? DetailViewController {
            
            if let indexPath = tableView.indexPathForSelectedRow {
                let VehicleItemArray = vehicleItems[indexPath.row]
                DetailViewController.vehicleItem = VehicleItemArray
            }
        }
    }

    // MARK: UITableViewDataSource
    
        override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vehicleItems.count
    }
    
    //This func is like the coordinates for the location of the cell
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
        
        let VehicleItemArray = vehicleItems[indexPath.row]
        
        cell.textLabel?.text = VehicleItemArray.make
        cell.detailTextLabel?.text = "Check it out!"
        
        return cell
        
        }
    }