//
//  ViewController.swift
//  Car Dealership Listings
//
//  Created by Michael Wiggins on 7/16/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import UIKit
import Foundation

class DetailViewController: UIViewController {
  
    
    
      // MARK: Declaration
    //this variable item, the array, has to be declared as an optional because...well I think it's because if it's not then you run the chance of getting a nil value, a condition which you avoid by using the "as" syntax pattern when you set up your datasource and datamodel. These labels could be text fields, I think, if I wanted to set this for the user to enter the data. Then the "if let" statement would be revised to say the outputs should be equal to the user's entries.
    
    var vehicleItem:VehicleItemArray?
    
    @IBOutlet weak var makeLabel: UILabel!
    @IBOutlet weak var modelLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    
    // MARK: Lifecycle - this refers to the sequence of events after the view appears
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        // If the Item entered is the same as itself, and of course it will be, then this instructs the compiler to output(print) the task in the label and it also tells it to make the description label equal to the description
       
        if let vehicleItem = vehicleItem {
            
            makeLabel.text = vehicleItem.make
            modelLabel.text = vehicleItem.model
            yearLabel.text = vehicleItem.year
            priceLabel.text = vehicleItem.price
            
            
        }
    }


}

