//
//  vehicleItemProtocol.swift
//  Car Dealership Listings
//
//  Created by Michael Wiggins on 7/16/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit

class VehicleItemArray {
        
        let make: String
        let model: String
        let year: String
        let price: String
        
        init(make: String, model: String, year: String, price: String) {
            self.make = make
            self.model = model
            self.year = year
            self.price = price
        }
    }
