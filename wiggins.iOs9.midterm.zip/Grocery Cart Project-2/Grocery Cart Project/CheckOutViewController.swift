//
//  checkOutViewController.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 8/1/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit


protocol CheckOutViewControllerDelegate: class{
    func calculateBill()-> Double
}

class CheckOutViewController: UIViewController {
    
    //Mark: Declaration of Variables
    var totalAmount:Double = 0
    var checkOutItems = [FruitBasket]()
    var cashTendered:Float = 0
    
    weak var delegate: CheckOutViewControllerDelegate?
    
//Mark: Labels and TextFields
    @IBOutlet weak var numberItems: UILabel!
    @IBOutlet weak var Amount: UILabel!
    @IBOutlet weak var Cash: UITextField!
   
//Mark: Life Cycle
    
  override func viewDidLoad() {
    
 
    }
    

    override func viewDidAppear(animated: Bool) {
       
        numberItems.text = "\(checkOutItems.count)"
        
        totalAmount = 0
        
        for item in checkOutItems {
            if let priceAsDouble = Double(item.price){
                print(priceAsDouble)
                totalAmount += priceAsDouble
                Amount.text = "\(totalAmount)"

            }

        }
    }
    
    //Mark: Actions

    @IBAction func Pay(sender: AnyObject) {
        
            }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
         if segue.identifier == "YourChangeSegueIdentifier" {
             if let YourChangeViewController = segue.destinationViewController as? YourChangeViewController {
                let cashTendered = Float(Cash.text!)!
                print(cashTendered)
                print(totalAmount)
                let theChange:Float = Float(cashTendered) - Float(totalAmount)
                YourChangeViewController.theChange = theChange
                dismissViewControllerAnimated(true, completion: nil)
            }
        }
    }
}