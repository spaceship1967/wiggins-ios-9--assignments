//
//  DetailViewController.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 7/28/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import Foundation
import UIKit

//Mark: Protocol Conformation
protocol DetailGroceryViewControllerDelegate:class {
    func userDidAddNewItem(selectedItem: FruitBasket)
}

    
class DetailGroceryViewController: UIViewController {

// MARK: Declaration of variables
    private var selectedItem = [FruitBasket]()
    
    weak var delegate:DetailGroceryViewControllerDelegate?
    

//Mark: Actions
    
    @IBAction func AppleBasket(sender: AnyObject) {
        
        let selectedItem = FruitBasket(name: "Apple Basket", price: "10")
        delegate?.userDidAddNewItem(selectedItem)
        dismissViewControllerAnimated(true, completion: nil)

    }
    

    @IBAction func BananaBasket(sender: AnyObject) {

        let selectedItem = FruitBasket(name: "Banana Basket", price: "10")
        delegate?.userDidAddNewItem(selectedItem)
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    @IBAction func AvocadoBasket(sender: AnyObject) {
        
        let selectedItem = FruitBasket(name: "Avocado Basket", price: "10")
        delegate?.userDidAddNewItem(selectedItem)
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    @IBAction func OrangeBasket(sender: AnyObject) {
        
        let selectedItem = FruitBasket(name: "Orange Basket", price: "10")
        delegate?.userDidAddNewItem(selectedItem)
        dismissViewControllerAnimated(true, completion: nil)
    }
    

    
//Mark: Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
