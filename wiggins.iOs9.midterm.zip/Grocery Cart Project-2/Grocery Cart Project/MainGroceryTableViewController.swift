//
//  ViewController.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 7/28/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//


import UIKit

class MainGroceryTableViewController: UITableViewController {
    private var selectedItems = [FruitBasket]()


//Mark: Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
//Mark Segue
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "detailsequeidentifier" {
            if let detailViewController = segue.destinationViewController as? DetailGroceryViewController {
                detailViewController.delegate = self
            }
        }
        
        if segue.identifier == "checkOutViewSegue" {
            if let CheckOutViewController = segue.destinationViewController as? CheckOutViewController {
                print ("hello 555555")
                CheckOutViewController.checkOutItems = selectedItems
            }
        }
    }

    
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selectedItems.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
        let purchases = selectedItems[indexPath.row]
        
        
        cell.textLabel?.text = purchases.name
        cell.detailTextLabel?.text = purchases.price
        
        return cell
        
    }
    
}


extension MainGroceryTableViewController: DetailGroceryViewControllerDelegate {
    func userDidAddNewItem(purchases: FruitBasket) {
        print("Hello")
        selectedItems.append(purchases)
        tableView.reloadData()
    }
        
}


extension MainGroceryTableViewController: CheckOutViewControllerDelegate {
    
    func calculateBill() -> Double {
            print("Adding stuff up")
        
        var totalAmount:Double = 0
    
        for item in selectedItems {
            if let priceAsDouble = Double(item.price){
                print(priceAsDouble)
                totalAmount += priceAsDouble
            }
        }
        print(totalAmount)
    
    return totalAmount
        
    }
    
}
