//
//  YourChange.swift
//  Grocery Cart Project
//
//  Created by Michael Wiggins on 8/3/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.

import Foundation
import UIKit

protocol YourChangeViewControllerDelegate: class{
    func calculateChange()-> Float
}
class YourChangeViewController: CheckOutViewController {

    
//Mark: Declaration of variables
var theChange:Float = 0
    

@IBOutlet weak var yourChange: UILabel!


//Mark: Life Cycle
    
    override func viewDidAppear(animated: Bool) {
        
        yourChange.text = "\(theChange)"
        
    }
}