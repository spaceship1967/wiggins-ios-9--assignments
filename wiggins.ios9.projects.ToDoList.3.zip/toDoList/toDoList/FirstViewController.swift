//
//  FirstViewController.swift
//  toDoList
//
//  Created by Michael Wiggins on 7/14/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import UIKit

var toDoList = [String]()

class FirstViewController: UIViewController, UITableViewDelegate {
    
    @IBOutlet var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if NSUserDefaults.standardUserDefaults().objectForKey("Tasks") != nil {
            toDoList = NSUserDefaults.standardUserDefaults().objectForKey("Tasks") as! [String]
        }
        
        self.tableView.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return toDoList.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .Default, reuseIdentifier: "cell")
        
        cell.textLabel?.text = toDoList[indexPath.row]
        
        return cell
}
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if editingStyle == UITableViewCellEditingStyle.Delete {
           
            toDoList.removeAtIndex(indexPath.row)
                NSUserDefaults.standardUserDefaults().setObject(toDoList, forKey: "tasks")
            tableView.reloadData()
        }
        
    }
    override func viewDidAppear(animated: Bool){
            tableView.reloadData()
        }
    }