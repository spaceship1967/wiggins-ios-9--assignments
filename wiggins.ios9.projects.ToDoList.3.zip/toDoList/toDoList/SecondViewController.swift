//
//  SecondViewController.swift
//  toDoList
//
//  Created by Michael Wiggins on 7/14/16.
//  Copyright © 2016 Michael Wiggins. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet var toDoListTextField: UITextField!
    
    @IBAction func addTask(sender: AnyObject) {
    
        toDoList.append(toDoListTextField.text!)
        toDoListTextField.text = ""
        
        NSUserDefaults.standardUserDefaults().setObject(toDoList, forKey: "Tasks")
    
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.toDoListTextField.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
    }
    
    func textFieldShouldReturn(toDoListTextField: UITextField) -> Bool {
        toDoListTextField.resignFirstResponder()
        return true
    }

}

